@extends('layouts.main')

@section('container')
    <h1>Halaman Gallery</h1>

@endsection